'use strict';
export const appName  = 'app';
export const baseURL = '/';
export const host = 'http://callback.vagrant/api/';
export const TOKEN_HEADER_NAME = 'Authorization';