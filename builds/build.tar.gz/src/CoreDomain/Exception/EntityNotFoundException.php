<?php

namespace CoreDomain\Exception;

class EntityNotFoundException extends DomainException
{
}
