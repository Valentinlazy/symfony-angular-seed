<?php

namespace CoreDomain\Exception;

class DomainException extends \Exception
{
}
