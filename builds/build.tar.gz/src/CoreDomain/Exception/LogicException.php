<?php

namespace CoreDomain\Exception;

class LogicException extends DomainException
{
}
