<?php

namespace CoreDomain\Exception;

class AccessDeniedException extends DomainException
{
}
