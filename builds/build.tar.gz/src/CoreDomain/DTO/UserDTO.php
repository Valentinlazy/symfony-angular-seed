<?php

namespace CoreDomain\DTO;

class UserDTO
{
    public $id;
    public $email;
    public $password;
    public $fullName;
}
