<?php

namespace CoreDomain\DTO;

class ProfileDTO
{
    public $password;
    public $fullName;
    public $phone;
}
